export interface BrandDto {
    id: string;
    name: string;
}
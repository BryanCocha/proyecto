export class GlobalParams {
    search?:any;
    sort: string= 'NAME';
    sortOrder: string = 'ASC';
    pageNumber: number = 0;
    pageSize: number = 5;
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-error',
  templateUrl: './default-error.component.html',
  styleUrls: ['./default-error.component.scss']
})
export class DefaultErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
